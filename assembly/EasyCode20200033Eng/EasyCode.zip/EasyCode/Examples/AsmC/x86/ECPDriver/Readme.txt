1 - Build the ECPDriver project.
2 - Then build the ECPDrvTest project.
3 - Run ECPDrvTest.exe (as an Administrator) and test the driver.
